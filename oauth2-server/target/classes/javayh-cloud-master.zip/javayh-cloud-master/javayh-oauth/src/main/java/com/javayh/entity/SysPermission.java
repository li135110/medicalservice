package com.javayh.entity;

import lombok.Data;

import java.util.Date;

/**
 * @author Dylan Yang
 * @Description: TODO
 * @Title: SysPermission
 * @ProjectName javayh-oauth2
 * @date 2019/5/18 15:12
 */
@Data
public class SysPermission {
    private int id;
    private String permissionUri;
//    private Date createDate;
//    private Date updateDate;
}

