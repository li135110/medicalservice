package com.javayh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavayhNioApplication {

    public static void main(String[] args) {
        SpringApplication.run(JavayhNioApplication.class, args);
    }

}
