package com.javayh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavayhCommonsApplication {

    public static void main(String[] args) {
        SpringApplication.run(JavayhCommonsApplication.class, args);
    }

}
