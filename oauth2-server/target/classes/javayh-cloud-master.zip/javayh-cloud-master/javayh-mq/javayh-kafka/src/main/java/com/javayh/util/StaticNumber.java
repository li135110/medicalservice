package com.javayh.util;

/**
 * @author Dylan Yang
 * @Description: StaticNumber
 * @Title: StaticNumber
 * @ProjectName javayh-cloud
 * @date 2019/7/17 15:15
 */
public interface StaticNumber {

    String JAVAYOHO = "JavaYoHo";
    String YANGHJ = "YangHaiJi";
    String DYLAN = "Dylan";

}
